require 'fastimage'

pics_on_page_num = 0
albums_num = 0
album_preview_num = 0
addr_to_explr = "address"
min_size = 0;
lim_prop = "no"
line_num=0
edit_me=File.open('edit_me.txt').read
edit_me.gsub!(/\r\n?/, "\n")
edit_me.each_line do |line|
	if (line.split(":").first == "the number of the pics on album\'s example") then
		album_preview_num = line.split(":").last.to_i
	end
	if (line.split(":").first == "the number of the albums") then
		albums_num = line.split(":").last.to_i + 1
	end
	if (line.split(":").first == "the number of the pics in gallery on one page") then
		pics_on_page_num = line.split(":").last.to_i + 1
	end
	if (line.split(":").first == "address to explore") then
		addr_to_explr = line.split(":").last.split(/\n/).first
	end
	if (line.split(":").first == "minimal dimensions") then
		min_size = line.split(":").last.to_i
	end
	if (line.split(":").first == "limitation of proportions yes or no") then
		lim_prop = line.split(":").last.split(/\n/).first
	end
end

class MyConfig
	def create(album)
		configfile = File.new("config/#{album}.txt", "w+")
		configfile.close
		configfile = File.new("config/PicExDGAllImgs.txt", "w+")
		configfile.close
	end
	def add(image_address,name,album,id,width,height,date)
		configfile = File.new("config/#{album}.txt", "a+")
		configfile.puts "#{image_address}*sep*#{name}*sep*#{album}*sep*#{id}*sep*#{width}*sep*#{height}*sep*#{date}"
		configfile.close
		configfile = File.new("config/PicExDGAllImgs.txt", "a+")
		configfile.puts "#{image_address}*sep*#{name}*sep*PicExDGAllImgs*sep*#{id}*sep*#{width}*sep*#{height}*sep*#{date}"
		configfile.close
	end
end

class Html
	def create_index_page
		pagefile = File.new("index.html", "w+")
		pagefile.puts "<html>\n\t<head>\n\t\t<meta content=\"text/html; charset=UTF-8;\" http-equiv=\"content-type\">\n\t\t<title>\n\t\t\tPicExDG\n\t\t</title>\n\t\t<link rel=\"stylesheet\" type=\"text/css\" href=\"html/css/main.css\">\n\t</head>\n\t<body>"
		pagefile.close
	end
	def create_page(page_name)
		pagefile = File.new("html/#{page_name}.html", "w+")
		pagefile.puts "<html>\n\t<head>\n\t\t<meta content=\"text/html; charset=UTF-8;\" http-equiv=\"content-type\">\n\t\t<title>\n\t\t\tPicExDG\n\t\t</title>\n\t\t<link rel=\"stylesheet\" type=\"text/css\" href=\"css/main.css\">\n\t</head>\n\t<body>"
		pagefile.close
	end
end

images = Array.new
id = 0
prop = 0.0
date = " "

Dir.glob("#{addr_to_explr}/**/*.*") do |image_address|
	if (image_address.split(/\./).last == "png") or (image_address.split(/\./).last == "bmp") or (image_address.split(/\./).last == "jpg") or (image_address.split(/\./).last == "jpeg") or (image_address.split(/\./).last == "gif") or (image_address.split(/\./).last == "tif") then
		dimensions = FastImage.size(image_address)
		width = dimensions[0]
		height = dimensions[1]

		if ((width >= min_size) or (width >= min_size)) then
			if (lim_prop == "yes") then
				if (width > height) then
					prop = width/height
				else				
					prop = height/width
				end
			end
			if (prop < 1.7777777777) then
				date = File.mtime(image_address).to_s
				date_in_secs = (date.split(" ")[1].split(":").last.to_i) + (date.split(" ")[1].split(":")[1].to_i*60) + (date.split(" ")[1].split(":")[0].to_i*60*60) + (date.split(" ")[0].split("-").last.to_i*24*60*60) + (date.split(" ")[0].split("-")[1].to_i*30*24*60*60) + (date.split(" ")[0].split("-")[0].to_i*12*30*24*60*60)
				name = image_address.split('/').last.split(/\./).first
				album = image_address.split('/')
				album = album[album.size - 2]
				id = id + 1
				if !images.include? [date_in_secs,image_address,name,album,id,width,height,date] then
					images << [date_in_secs,image_address,name,album,id,width,height,date]
				end
			end
		end
	end
end

for i in 0..id-1 do
	MyConfig.new.create(images[i][3])
end

images.sort.reverse.each do |element|
	temp = element[0]
	element[0] = element[1]
	element[1] = element[2]
	element[2] = element[3]
	element[3] = element[4]
	element[4] = element[5]
	element[5] = element[6]
	element[6] = element[7]
	element[7] = temp
	MyConfig.new.add(element[0],element[1],element[2],element[3],element[4],element[5],element[6])
end

Html.new.create_index_page

Dir.glob("#{Dir.pwd}/config/*.txt") do |my_config_file|
	only_name = my_config_file.split("/").last.split(".txt").first
	Html.new.create_page(only_name)
end

album_counter = 0
page_counter = 2
page_counter2 = 2
photo_counter = 0
page_name = "index.html"
page_name2 = "example.html"

Dir.glob("#{Dir.pwd}/config/*.txt") do |my_config_file|
	page_counter2 = 2
	i = 0
	k = 0
	if (album_counter > 0) then
		pagefile = File.new(page_name, "a+")
		pagefile.puts "</p></a></div>"
		pagefile.close
	else
		pagefile = File.new(page_name, "a+")
		pagefile.puts "<div id=\"buttons\"><a id = \"nextprevious\" href = \"html/PicExDGAllImgs.html\">All photos in gallery</a></div>"
		pagefile.close
	end
	album_counter = album_counter + 1
	text=File.open(my_config_file).read
	text.gsub!(/\r\n?/, "\n")
	text.each_line do |line|
		k = k + 1
	end
	my_config_file = my_config_file.split("/").last.split(".txt").first
	page_name2 = "#{my_config_file}.html"
	pagefile2 = File.new("html/#{page_name2}", "a+")
	random = Random.rand(2)
		if (random == 1) then
			pagefile2.puts "\t\t<div class = \"album2\">"
		else
			pagefile2.puts "\t\t<div class = \"album\">"
		end
	
	text.each_line do |line|
		photo_counter = photo_counter + 1
		if (photo_counter == pics_on_page_num) then #the number of the pics in gallery + 1
			pagefile2.puts "\t\t</div>"
			
			if ((page_counter2 - 2 != 1) and (page_counter2 - 2 != 0)) then
				pagefile2.puts "<div id=\"buttons\"><a id = \"nextprevious\" href = \"#{my_config_file}#{page_counter2-2}.html\">Previous</a>"
			else
				if (page_counter2 - 2 == 0) then
					if (page_counter - 1 != 1)
						pagefile2.puts "<div id=\"buttons\"><a id = \"nextprevious\" href = \"#{Dir.pwd}/index#{page_counter - 1}.html\">Previous</a>"
					else
						pagefile2.puts "<div id=\"buttons\"><a id = \"nextprevious\" href = \"#{Dir.pwd}/index.html\">Previous</a>"
					end
				else
				pagefile2.puts "<div id=\"buttons\"><a id = \"nextprevious\" href = \"#{my_config_file}.html\">Previous</a>"
				end
			end
			pagefile2.puts "<a id = \"nextprevious\" href = \"#{my_config_file}#{page_counter2}.html\">Next</a></div>"
			pagefile2.puts "</body></html>"
			pagefile2.close
			Html.new.create_page("#{my_config_file}#{page_counter2}")
			page_name2 = "#{my_config_file}#{page_counter2}.html"
			pagefile2 = File.new("html/#{page_name2}", "a+")
			pagefile2.puts "\t\t<div class = \"album\">"
			photo_counter = 1
			page_counter2 = page_counter2 + 1
		end
		random = Random.rand(2)
		if (random == 1) then
			pagefile2.puts "\t\t\t#{line.split("*sep*")[6].split(" ").first}<a id=\"images_and_date\" href=\"#{line.split("*sep*")[0]}\" alt=\"#{line.split("*sep*")[1]}\" target=\"_blank\"><img src=\"#{line.split("*sep*")[0]}\" alt=\"#{line.split("*sep*")[1]}\" id=\"gallery_photo\" title = \"#{line.split("*sep*")[1][0..20]}..#{line.split("*sep*")[0][-4..-1]} [#{line.split("*sep*")[4]}px X #{line.split("*sep*")[5]}px]\"/></a>"
		else
			pagefile2.puts "\t\t\t<a id=\"images_and_date\" href=\"#{line.split("*sep*")[0]}\" alt=\"#{line.split("*sep*")[1]}\" target=\"_blank\"><img src=\"#{line.split("*sep*")[0]}\" alt=\"#{line.split("*sep*")[1]}\" id=\"gallery_photo\" title = \"#{line.split("*sep*")[1][0..20]}..#{line.split("*sep*")[0][-4..-1]} [#{line.split("*sep*")[4]}px X #{line.split("*sep*")[5]}px]\"/></a>#{line.split("*sep*")[6].split(" ").first}"
		end
		random = Random.rand(5)
		if (random == 2) then
			pagefile2.puts "<br></br>"
		end
		
		i = i + 1
		if (album_counter == albums_num) then #the number of the albums + 1
			pagefile = File.new(page_name, "a+")
			previous = "index#{page_counter - 2}.html"
			if previous == "index1.html" then
				previous = "index.html"
			end
			if (page_name != "index.html") then
				pagefile.puts "<div id=\"buttons\"><a id = \"nextprevious\" href = \"#{previous}\">Previous</a>"
			else
				pagefile.puts "<div id=\"buttons\">"
			end
			page_name = "index#{page_counter}.html"
			pagefile.puts "<a id = \"nextprevious\" href = \"#{page_name}\">Next</a></div>"
			pagefile.close
			pagefile = File.new(page_name, "w+")
			pagefile.puts "<html>\n\t<head>\n\t\t<meta content=\"text/html; charset=UTF-8;\" http-equiv=\"content-type\">\n\t\t<title>\n\t\t\tPicExDG\n\t\t</title>\n\t\t<link rel=\"stylesheet\" type=\"text/css\" href=\"html/css/main.css\">\n\t</head>\n\t<body>"
			album_counter = 1
			page_counter = page_counter + 1
			pagefile.puts "<div id=\"buttons\"><a id = \"nextprevious\" href = \"html/PicExDGAllImgs.html\">All photos in gallery</a></div>"
			pagefile.close
		end
		if (i == 1) then
			pagefile = File.new(page_name, "a+")
			pagefile.puts "<div class = \"album\"><a href = \"html/#{line.split("*sep*")[2]}.html\" target=\"_blank\"><p id = \"title\">#{line.split("*sep*")[2]}: [#{k} photos]</p><p>"
			pagefile.close
		end
		if (i <= album_preview_num) then #the number of the pics on album's example
			pagefile = File.new(page_name, "a+")
			pagefile.puts "<img src=\"#{line.split("*sep*")[0]}\" alt=\"#{line.split("*sep*")[1]}\" id=\"index_photo\"/>"
			pagefile.close
		end
	end
	pagefile2.puts "\t\t</div>"
	if (page_counter2 - 2 > 1) then
		pagefile2.puts "<div id=\"buttons\"><a id = \"nextprevious\" href = \"#{my_config_file}#{page_counter2 - 2}.html\">Previous</a></div>"
	else
		pagefile2.puts "<div id=\"buttons\"><a id = \"nextprevious\" href = \"#{my_config_file}.html\">Previous</a></div>"
	end
	pagefile2.puts "</body></html>"
	pagefile2.close
end

pagefile = File.new(page_name, "a+")
pagefile.puts "</p></a></div>"
pagefile.puts "<div id=\"buttons\"><a id = \"nextprevious\" href = \"index#{page_counter - 2}.html\">Previous</a></div>"
pagefile.close
