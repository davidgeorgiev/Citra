class MyConfig
	def create(image_address,name,album,id)
		configfile = File.new("config/#{album}.txt", "a+")
		configfile.puts "#{image_address},#{name},#{album},#{id}"
		configfile.close
		configfile = File.new("config/PicExDGAllImgs.txt", "a+")
		configfile.puts "#{image_address},#{name},PicExDGAllImgs,#{id}"
		configfile.close
	end
end

class Html
	def create_page(page_name)
		pagefile = File.new("html/#{page_name}.html", "w+")
		pagefile.puts ""
		pagefile.close
	end
	def add_element(page_name,line)
		pagefile = File.new("html/#{page_name}.html", "a+")
		pagefile.puts "#{line}"
		pagefile.close
	end
end

images = Array.new
id = 0

Dir.glob("#{ARGV[0]}/**/*.*") do |image_address|
	if (image_address.split(/\./).last == "png") or (image_address.split(/\./).last == "bmp") or (image_address.split(/\./).last == "jpg") or (image_address.split(/\./).last == "jpeg") then
		name = image_address.split('/').last.split(/\./).first
		album = image_address.split('/')
		album = album[album.size - 2]
		
		id = id + 1

		if !images.include? [image_address,name,album,id] then
			images << [image_address,name,album,id]
		end
	end
end

for i in 0..id-1 do
	MyConfig.new.create(images[i][0],images[i][1],images[i][2],images[i][3])
end

Dir.glob("#{Dir.pwd}/config/*.txt") do |my_config_file|
	only_name = my_config_file.split("/").last.split(".txt").first
	Html.new.create_page(only_name)
end

Dir.glob("#{Dir.pwd}/config/*.txt") do |my_config_file|
	text=File.open(my_config_file).read
	text.gsub!(/\r\n?/, "\n")
	text.each_line do |line|
		my_config_file = my_config_file.split("/").last.split(".txt").first
		Html.new.add_element(my_config_file,line)
	end
end
